## Additional Terms (No Selling Clause)

While this project is licensed under AGPL-3.0, the original author ([GlaceYT](https://github.com/GlaceYT)) explicitly **prohibits**:

- Selling the bot or modified versions of it
- Using the bot or its derivatives for **any commercial gain**
- Removing or altering author credits

This is a moral and community-driven restriction in line with the spirit of open-source. Violators may face takedowns or blacklisting from open-source platforms and Discord’s Trust & Safety system.

You are free to use, modify, and host this bot for **personal** or **community** purposes only.
