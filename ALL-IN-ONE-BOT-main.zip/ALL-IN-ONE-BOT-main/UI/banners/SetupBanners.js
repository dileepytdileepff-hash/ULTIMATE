const setupBanners = {
    helpBanner : 'https://i.ibb.co/7dFy30km/ALL-IN-ONE-1-4-BETA.png',
    verificationBanner : 'https://i.ibb.co/pjHDXzXx/static.png',
    ticketBanner : 'https://i.ibb.co/h1DBsRnv/ticket.gif',
    autovcBanner : 'https://i.ibb.co/mk6Tj1r/autovc.gif',
    economyBanner : 'https://www.animatedimages.org/data/media/562/animated-line-image-0015.gif',
};

module.exports = setupBanners;
