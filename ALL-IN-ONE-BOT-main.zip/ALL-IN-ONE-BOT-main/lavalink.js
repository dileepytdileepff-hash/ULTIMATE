
module.exports = {
    enabled: true, 
    lavalink: {
      name: "GlceYT",
      password: "glace",
      host: "de-01.strixnodes.com",
      port: 2010,
      secure: false
    }
};           


